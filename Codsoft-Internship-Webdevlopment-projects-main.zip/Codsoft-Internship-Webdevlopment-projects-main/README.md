# Codsoft-Internship-Webdevlopment-projects
I'm excited to announce that I'll be participating in the Codsoft online internship for web development. During this internship, my mentor has assigned me three exciting projects: creating a responsive calculator, designing a captivating landing page, and developing a professional portfolio website.
